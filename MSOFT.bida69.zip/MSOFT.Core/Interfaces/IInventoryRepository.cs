﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MSOFT.Core.Interfaces
{
    public interface IInventoryRepository: IBaseRepository
    {

    }
}
