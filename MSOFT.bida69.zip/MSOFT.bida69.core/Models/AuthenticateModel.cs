using System.ComponentModel.DataAnnotations;

namespace MSOFT.bida69.Models
{
    public class AuthenticateModel
    {
        [Required]
        public string Username { get; set; }

        [Required]
        public string Password { get; set; }
    }
}