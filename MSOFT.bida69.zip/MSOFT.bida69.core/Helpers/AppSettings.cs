namespace MSOFT.bida69.core.Helpers
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}