﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MSOFT.DL.Interfaces
{
    public interface IInventoryRepository: IBaseRepository
    {

    }
}
